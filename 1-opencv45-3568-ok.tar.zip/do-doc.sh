
echo ""
echo "================================"
echo "cmake  RELEASE \
	 /usr/local "
	 	 
	 echo ""
	 echo ""

	 cmake \
		 -D CMAKE_BUILD_TYPE=RELEASE  \
		 -D CMAKE_INSTALL_PREFIX=../../opencv45  \
		 -D OPENCV_EXTRA_MODULES_PATH=../../opencv_contrib-4.5.0/modules    \
		 -D BUILD_TESTS=OFF  \
		 -D BUILD_OPENCV_CALIB3D=OFF  \
		 -D BUILD_OPENCV_ANNOTATION=OFF  \
		 -D BUILD_opencv_perf_core=OFF  \
		 -D BUILD_opencv_perf_photo=OFF  \
		 -D BUILD_opencv_perf_imgproc=OFF \
		 -D BUILD_OPENCV_visualisation=OFF  \
		   ..

